package com.chrischoong96.smartmove

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
